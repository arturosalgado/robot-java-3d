
import java.io.*;

public class EjecutarData 

{
	
		public String nombre_pieza;
		public String metodo;
		public String valor;
		
		
		int    valor_entero;

		EjecutarData()
		{
					
			nombre_pieza="";
			metodo="";
			valor="";				
			
		}
	
	
		
}