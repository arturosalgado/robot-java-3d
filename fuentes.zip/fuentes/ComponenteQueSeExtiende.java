import javax.media.j3d.*;

class  ComponenteQueSeExtiende extends Componente implements InterfazExtiende

{
	
	
	ComponenteQueSeExtiende()
	{
		
		tg_translada.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);	
		tg_translada.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);	

		
		
	}
	
	public void extender(int distancia)
	{
		
		
	}
	
	public void contraer(int distancia)
	{
		
		
		
	}

		
	
	
	
}