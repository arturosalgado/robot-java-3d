// de los angeles salgado jose arturo 
// editor simulador de robots orientado a objetos
import javax.media.j3d.*;



interface InterfazExtiende

{
	
	public void extender(int distancia,int resolucion , boolean modo);
	public void contraer(int distancia,int resolucion, boolean modo);
	
	
}