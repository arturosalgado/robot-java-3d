// de los angeles salgado jose arturo 
// editor simulador de robots orientado a objetos

import javax.media.j3d.*;

interface InterfazRotar

{
	
	TransformGroup tg_rotar= new TransformGroup();
	
	public void rotar(int grados);

	
}